# Instagram-Automation-Tool
It will Automate log-in , scroll, click, Explore, like, follow, comment, log-out .
